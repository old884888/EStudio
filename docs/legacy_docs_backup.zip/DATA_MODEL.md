# EStudio — 数据模型

## 1. 核心数据结构

所有数据存为 JSON，便于 AI 直接读写。不使用数据库——保持简单。

---

## 2. 课程树 `curriculum.json`

```jsonc
{
  "version": "1.0",
  "subject": "Python 全流程",
  "description": "从零基础到能独立开发命令行工具",
  "created_at": "2026-07-17T10:00:00",
  "updated_at": "2026-07-17T14:30:00",
  "status": "in_progress",       // not_started | in_progress | completed | paused
  "current_node": "m1_c2",       // 当前正在学的节点 ID

  "concept_graph": {
    // 概念依赖图：学 A 之前必须掌握 B
    "list_comprehension": {
      "depends_on": ["lists", "for_loops", "conditionals"],
      "appears_in": ["m2_c2"]
    },
    "function_decorators": {
      "depends_on": ["functions", "higher_order_functions"],
      "appears_in": ["m3_c3"]
    }
  },

  "modules": [
    {
      "id": "m1",
      "title": "基础语法",
      "description": "Python 的基本语法元素",
      "status": "in_progress",
      "order": 1,
      "chapters": [
        {
          "id": "m1_c1",
          "title": "变量与数据类型",
          "status": "completed",
          "mastery": 0.85,
          "started_at": "2026-07-17T10:00:00",
          "completed_at": "2026-07-17T11:30:00",
          "session_count": 1,
          "struggles": [],
          "notes_file": "notes/m1_c1_变量与数据类型.md",
          "one_liner": "数据有类型(type)，变量是名字，Python 是动态类型的"
        },
        {
          "id": "m1_c2",
          "title": "条件语句",
          "status": "in_progress",
          "mastery": 0.45,
          "started_at": "2026-07-17T13:00:00",
          "session_count": 2,
          "last_position": "讲完了 if/elif/else 的执行顺序，还没讲嵌套条件",
          "struggles": ["elif 的执行顺序"],
          "notes_file": null,
          "one_liner": null
        },
        {
          "id": "m1_c3",
          "title": "循环",
          "status": "not_started",
          "mastery": null,
          "session_count": 0,
          "struggles": [],
          "notes_file": null,
          "one_liner": null
        }
      ]
    },
    {
      "id": "m2",
      "title": "函数与模块",
      "status": "not_started",
      "order": 2,
      "chapters": [
        {
          "id": "m2_c1",
          "title": "函数定义与调用",
          "status": "not_started",
          "mastery": null,
          "session_count": 0,
          "struggles": [],
          "notes_file": null,
          "one_liner": null
        },
        {
          "id": "m2_c2",
          "title": "参数与返回值",
          "status": "not_started",
          "mastery": null,
          "session_count": 0,
          "struggles": [],
          "notes_file": null,
          "one_liner": null
        }
      ]
    }
  ],

  "milestones": [
    {
      "after_chapters": ["m1_c3"],
      "title": "猜数字游戏",
      "description": "综合运用变量、条件、循环写一个终端小游戏",
      "required_concepts": ["variables", "conditionals", "loops"],
      "status": "not_started"
    },
    {
      "after_chapters": ["m2_c2"],
      "title": "命令行记账本",
      "description": "用函数封装实现收支记录与统计",
      "required_concepts": ["functions", "parameters", "return_values"],
      "status": "not_started"
    }
  ]
}
```

### 节点状态机

```
not_started ──→ in_progress ──→ completed
                                    │
                                    ▼
                              mastery >= 0.7 ?
                              ├─ yes → 进入复习队列
                              └─ no  → 标记为待重学
```

---

## 3. 知识状态 `knowledge.json`

```jsonc
{
  "subject": "Python 全流程",
  "updated_at": "2026-07-17T14:30:00",

  "mastery_map": {
    // concept_name → mastery_detail
    "variables": {
      "mastery": 0.85,
      "last_practiced": "2026-07-17T11:30:00",
      "evidence": [
        { "type": "exercise_correct", "detail": "变量赋值练习全对", "at": "2026-07-17T11:00:00" },
        { "type": "could_explain", "detail": "用户能用自己话解释动态类型", "at": "2026-07-17T11:20:00" }
      ]
    },
    "conditionals_if_elif": {
      "mastery": 0.45,
      "last_practiced": "2026-07-17T14:00:00",
      "evidence": [
        { "type": "struggle_repeated", "detail": "elif执行顺序连续问3次", "at": "2026-07-17T14:00:00" }
      ],
      "backtrack_suggestion": null
    }
  },

  "weak_points": [
    {
      "concept": "conditionals_if_elif",
      "detected_at": "2026-07-17T14:00:00",
      "severity": "medium",
      "occurrence_count": 3,
      "suggested_action": "用流程图可视化 if/elif/else 的执行流程"
    }
  ]
}
```

---

## 4. 困惑锚点 `pain_points.json`

```jsonc
[
  {
    "id": "pp_001",
    "concept": "elif 执行顺序",
    "triggered_at": "2026-07-17T14:32:00",
    "user_utterance": "等一下，那如果前面有个 if 已经满足了，elif 还会执行吗？",
    "resolved": false,
    "resolved_at": null,
    "resolution_note": null,
    "occurrence_count": 2
  }
]
```

### 困惑锚点 vs 薄弱点

| | 困惑锚点 (Pain Point) | 薄弱点 (Weak Point) |
|---|---|---|
| 本质 | 事件 | 状态 |
| 来源 | 用户的困惑时刻 | mastery 计算得出 |
| 触发 | 用户说"不懂"/反复问同类问题 | mastery < 0.5 |
| 时效 | 解决后标记 resolved | 持续存在直到重新评估 |

---

## 5. 复习队列 `review_queue.json`

```jsonc
[
  {
    "chapter_id": "m1_c1",
    "title": "变量与数据类型",
    "completed_at": "2026-07-17T11:30:00",
    "mastery_at_completion": 0.85,
    "review_count": 0,
    "next_review": "2026-07-18T12:00:00",  // 1天后
    "review_interval_hours": 24,
    "notes_file": "notes/m1_c1_变量与数据类型.md"
  }
]
```

### 间隔算法

```
初始间隔 = 24h

每次复习后：
  表现为"轻松"  → interval × 2.5
  表现为"一般"  → interval × 1.5
  表现为"吃力"  → interval × 1.0（重置）
  表现为"忘记"  → interval × 0.5 + 建议重学
```

---

## 6. 会话存档 `sessions/`

```jsonc
// sessions/m1_c2_20260717T130000.json
{
  "id": "sess_20260717T130000",
  "chapter_id": "m1_c2",
  "started_at": "2026-07-17T13:00:00",
  "ended_at": "2026-07-17T14:30:00",
  "status": "active",           // active | completed | interrupted
  "checkpoints": [
    {
      "at": "2026-07-17T13:30:00",
      "position": "讲完了 if 基本语法，准备讲 elif",
      "auto_saved": true
    },
    {
      "at": "2026-07-17T14:00:00",
      "position": "用户问了 3 个关于 elif 执行顺序的问题，刚讲完嵌套条件",
      "auto_saved": true
    }
  ],
  "pain_points_raised": ["pp_001"],
  "message_count": 45,
  "token_used": 12000
}
```

---

## 7. 笔记文件 `notes/{chapter_id}_{title}.md`

```markdown
# 第 2 节：条件语句

> 学习时间：2026-07-17 13:00 - 14:30
> 掌握度：★★☆☆☆ (45%)

## 核心概念

- `if` 后面跟一个布尔表达式，为 `True` 时执行缩进块
- `elif` = else if，是上一个条件不满足时的备选判断
- `else` 是兜底——前面所有条件都不满足时执行
- **一条 if/elif/else 链中，最多只有一条分支会执行**

## 关键代码

```python
score = 85

if score >= 90:
    grade = "A"
elif score >= 80:
    grade = "B"    # ← 这里会被命中
elif score >= 70:
    grade = "C"    # ← 即使这也满足，但不会执行
else:
    grade = "F"

print(grade)  # B
```

## 你踩过的坑

1. **以为 elif 可以独立使用** →不行，elif 前面必须有 if
2. **忘了加冒号 `:`** → `if score > 60` 而不是 `if score > 60`
3. **缩进不一致** → Python 用缩进表示代码块，别混用 Tab 和空格

## 与前面知识的关联

- 条件里的 `score >= 90` 是真假值（布尔值），就是上一节学的 `bool` 类型
- 等于判断用 `==`，赋值用 `=`，别搞混（第一节讲的）

## 下次复习重点

- 嵌套条件（if 里面再写 if）
- 多个条件的组合（and, or, not）
```

---

## 8. 数据一致性与版本

- 所有文件带 `version` 字段，便于后续演进
- `updated_at` 时间戳用于冲突检测
- 写入时使用原子写（write to temp → rename），防止写入中断导致损坏
- 会话过程中每 30 秒自动 checkpoint 一次
