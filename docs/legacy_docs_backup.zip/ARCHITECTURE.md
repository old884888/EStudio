# EStudio — 系统架构

## 1. 架构总览

```
┌──────────────────────────────────────────────┐
│                 CLI / Web UI                  │
│         对话窗口  +  侧边进度面板              │
└────────────────────┬─────────────────────────┘
                     │
┌────────────────────▼─────────────────────────┐
│              Session Manager                  │
│   ┌──────────────────────────────────────┐   │
│   │  加载状态 → 教学 → 定期存档 → 结束    │   │
│   └──────────────────────────────────────┘   │
└──────┬──────────────────┬───────────────────┘
       │                  │
┌──────▼──────┐   ┌───────▼────────┐
│  State Store │   │  AI Provider   │
│  (文件系统)   │   │  (LLM API)     │
└──────┬──────┘   └────────────────┘
       │
┌──────▼───────────────────────────────────────┐
│               Data Layer                      │
│  ┌──────────┐ ┌──────────┐ ┌──────────────┐  │
│  │ 课程树   │ │ 知识状态  │ │   笔记库     │  │
│  │ curriculum│ │ knowledge │ │   notes/     │  │
│  │ .json    │ │ .json    │ │              │  │
│  └──────────┘ └──────────┘ └──────────────┘  │
│  ┌──────────┐ ┌──────────┐ ┌──────────────┐  │
│  │ 复习队列 │ │ 困惑锚点  │ │  项目里程碑   │  │
│  │ review_  │ │ pain_    │ │  milestones  │  │
│  │ queue.json│ │ points.json│ │  .json       │  │
│  └──────────┘ └──────────┘ └──────────────┘  │
└──────────────────────────────────────────────┘
```

核心原则：**对话是瞬态的（ephemeral），数据是持久的（persistent）。**

---

## 2. 模块职责

### 2.1 Curriculum Manager（课程管理器）

管理课程树文件 `curriculum.json`。

```
输入：学习主题（如 "Python 全流程"）
输出：一棵课程树（YAML/JSON）

操作：
  - generate(subject): 调用 AI 生成大纲
  - getProgress(): 返回当前进度快照
  - updateNode(nodeId, patch): 更新某个节点的状态
  - getNextPending(): 返回下一个未完成的节点
  - getDependencies(nodeId): 返回概念依赖图
```

### 2.2 Session Manager（会话管理器）

每次学习的生命周期管理。

```
Session 生命周期：

  1. [启动] 加载课程树 + 知识状态
  2. [回顾] 展示上次位置 + 待办 + 待复习
  3. [教学] AI 对话（有明确章节边界）
  4. [归档] 对话结束 → 更新课程树 → 生成笔记 → 更新复习队列
  5. [保存] 写入所有数据文件

中断处理：
  - 每 30 秒自动存档一次（debounced）
  - 关闭时强制存档
  - 下次启动检测到未完成会话 → 提供恢复选项
```

### 2.3 Knowledge State Manager（知识状态管理器）

追踪每个知识点的掌握程度。

```
mastery 计算规则：

  0.9+  能独立向别人讲清楚
  0.7-0.9 做对练习，偶有小错
  0.4-0.6 练习需要提示
  0.1-0.3 基本不会

降权/衰减：
  - 超过 review_interval 未复习 → mastery × 0.8
  - 同一 pain_point 重复触发 → mastery 打标"需要回溯"
```

### 2.4 Note Generator（笔记生成器）

每次会话结束后调用 AI 生成结构化笔记。

```
输入：本次会话的完整对话
输出：结构化笔记文件

笔记模板：
  1. 核心概念（一句话）
  2. 关键代码片段
  3. 你踩过的坑
  4. 与前面知识的关联
  5. 下次复习重点
```

### 2.5 Review Scheduler（复习调度器）

```
复习算法（简化版 SM-2）：
  - 第 1 次复习：1 天后
  - 第 2 次复习：3 天后
  - 第 3 次复习：7 天后
  - 第 4 次复习：14 天后

每次复习后根据表现调整间隔。
```

### 2.6 AI Provider（AI 接口层）

```
职责：
  - 封装 LLM API 调用
  - 管理 System Prompt（按模式不同）
  - Token 计数与控制
  - 支持切换模型

模式 System Prompt 差异：
  - 教学模式：讲解者（讲概念 + 给例子 + 引导思考）
  - 练习模式：出题者（出题 + 判题 + 点评，不给直接答案）
  - 复习模式：测试者（快速提问 + 检测遗忘）
  - 项目模式：导师（引导方向，不替写代码）
```

---

## 3. 数据流图

```
用户启动工具
    │
    ▼
Session Manager 启动
    │
    ├─ 加载 curriculum.json      → 侧边栏显示进度树
    ├─ 加载 knowledge.json       → 展示薄弱点提醒
    ├─ 加载 review_queue.json    → 展示复习提醒
    ├─ 检测有无未完成 session     → 提供恢复
    │
    ▼
用户选择「继续学习」
    │
    ▼
Session Manager 构造 System Prompt
  （注入：current_node + 历史薄弱点 + 上次笔记摘要）
    │
    ▼
进入对话循环
    │
    ├─ 用户输入
    ├─ AI 回复
    ├─ [定期] 自动存档检查点
    │
    ▼
用户说「结束本节」
    │
    ▼
Session Manager 调用 Note Generator
    │
    ├─ AI 生成笔记 → 写入 notes/
    ├─ 更新 curriculum.json 对应节点
    ├─ 更新 knowledge.json
    ├─ 更新 review_queue.json
    │
    ▼
显示：本节总结 + 下一步建议
```

---

## 4. 文件结构

```
EStudio/
├── docs/                    # 设计文档
│   ├── PRD.md
│   ├── ARCHITECTURE.md
│   ├── DATA_MODEL.md
│   ├── SESSION_DESIGN.md
│   └── ROADMAP.md
├── src/                     # 源代码
│   ├── main.py              # 入口
│   ├── session_manager.py   # 会话生命周期
│   ├── curriculum.py        # 课程树 CRUD
│   ├── knowledge.py         # 知识状态
│   ├── notes.py             # 笔记生成
│   ├── review.py            # 复习调度
│   ├── ai_provider.py       # LLM 接口
│   └── ui.py                # 界面
├── data/                    # 用户数据（git ignore）
│   └── subjects/
│       └── python/
│           ├── curriculum.json
│           ├── knowledge.json
│           ├── review_queue.json
│           ├── pain_points.json
│           └── notes/
│               ├── m1_c1_变量与数据类型.md
│               └── ...
├── prompts/                 # System Prompt 模板
│   ├── teacher.md
│   ├── exercise.md
│   ├── review.md
│   └── mentor.md
└── README.md
```
