# EStudio — 技术选型分析

## 一、多主题支持确认

**已经考虑到了。** 在 `DATA_MODEL.md` 和 `ARCHITECTURE.md` 中，数据结构是 subject-agnostic 的：

```
data/
  subjects/
    python/          ← 一个主题
      curriculum.json
      knowledge.json
      ...
    javascript/      ← 另一个主题
      curriculum.json
      ...
    linear-algebra/  ← 数学也行
      ...
```

课程树中的 `subject` 字段、模块结构、概念依赖图——全部是通用的。**EStudio 不是"Python 学习工具"，而是"结构化学习引擎"。** Python 只是碰巧你第一个要学的东西。

但有一个修正：之前 ROADMAP 把"多主题支持"放在 Phase 9（v1.0）太晚了。**应该从 v0.1 就支持多主题**，因为它只是同一个数据结构的多个实例，几乎零额外成本。

---

## 二、技术栈全面对比

### 2.1 语言选择

#### A. Python

| 维度 | 评价 |
|---|---|
| 学习曲线 | ★★★★★ 最低，语法接近自然语言 |
| AI/LLM 生态 | ★★★★★ openai、anthropic、langchain 一等公民 |
| CLI 库 | ★★★★☆ rich、textual、click、typer 都很成熟 |
| 异步 | ★★★☆☆ asyncio 能用但不如 Node.js 顺手 |
| 类型系统 | ★★★☆☆ 可选类型，不强制，大项目容易乱 |
| 打包分发 | ★★☆☆☆ pip/uv 可以但不如单二进制方便 |
| 性能 | ★★★☆☆ 够用，纯 I/O 型瓶颈不在语言 |

**适合你的原因**：你正在学 Python。写这个工具的过程本身就是项目实战。AI 对 Python 代码的理解和生成质量最高。

#### B. TypeScript / Node.js

| 维度 | 评价 |
|---|---|
| 学习曲线 | ★★★☆☆ 中等，TypeScript 类型系统需要时间 |
| AI/LLM 生态 | ★★★★☆ Vercel AI SDK、LangChain.js 很强 |
| CLI 库 | ★★★★☆ ink (React 写 CLI)、commander、pastel |
| 异步 | ★★★★★ 原生 async/await，事件驱动天然适配 |
| 类型系统 | ★★★★★ 静态类型，重构安全，IDE 提示好 |
| 打包分发 | ★★★☆☆ npm 生态庞大但 node_modules 地狱 |
| 与 Web UI 复用 | ★★★★★ CLI 和 Web 可以共享核心逻辑 |
| 性能 | ★★★★☆ 比 Python 快，I/O 密集场景表现好 |

**适合你的原因**：如果后期想做 Web UI，TypeScript 可以前后端共用代码。但起步比 Python 多一道类型系统的学习成本。

#### C. Go

| 维度 | 评价 |
|---|---|
| 学习曲线 | ★★★☆☆ 语法简单，但并发模型和错误处理有门槛 |
| AI/LLM 生态 | ★★☆☆☆ 官方 SDK 基本靠手写 HTTP 请求 |
| CLI 库 | ★★★★★ bubbletea、lipgloss、cobra — TUI 天花板 |
| 异步 | ★★★★★ goroutine + channel，最强并发模型 |
| 类型系统 | ★★★★☆ 静态类型 + 接口，但泛型比较新 |
| 打包分发 | ★★★★★ 编译成单文件二进制，零依赖 |
| 性能 | ★★★★★ 编译型语言，快 |

**适合你的原因**：想做精美的 TUI（终端 UI）工具，Go 的 bubbletea 生态是金字塔尖。但 AI 辅助写 Go 的质量不如 Python/TS，你也不熟 Go 的话学习成本叠加。

#### D. Rust

| 维度 | 评价 |
|---|---|
| 学习曲线 | ★☆☆☆☆ 陡峭，所有权/借用/生命周期概念重 |
| 适合这个项目 | ★☆☆☆☆ 这个项目是 I/O 密集型，Rust 的优势（内存安全/零成本抽象）用不上 |

**结论：不适合。** 杀鸡用牛刀，还会拖慢迭代速度。

---

### 2.2 语言选择决策矩阵

```
你的约束条件：
  1. 正在学 Python ← 最大影响因素
  2. 全程用 AI 辅助开发 ← AI 对 Python 代码质量最高
  3. 项目本身是学习目的 ← 选 Python = 一举两得
  4. 可能需要 Web UI ← Python 也有 FastAPI/Streamlit

                Python    TypeScript    Go
AI 辅助开发      ★★★★★      ★★★★☆      ★★★☆☆
你自己熟练度    学习中       ？          ？
项目复杂度匹配    ★★★★★      ★★★★☆      ★★★☆☆
Web UI 扩展      ★★★★☆      ★★★★★      ★★★☆☆
CLI 体验         ★★★★☆      ★★★★☆      ★★★★★

推荐：Python，如果未来你学了 TS 可以考虑重构。
```

---

### 2.3 UI 方案

#### A. 纯 CLI（rich + textual）

```
┌──────────────────────────────────┐
│  EStudio - Python 全流程          │
│  ──────────────────────────────── │
│                                   │
│  ▶ 继续上次：条件语句 (m1_c2)      │
│    上次进度：elif 执行顺序...       │
│                                   │
│  ○ 开始新课                        │
│  ○ 复习：变量与数据类型 (待复习)     │
│  ○ 浏览笔记                        │
│                                   │
└──────────────────────────────────┘
```

| 优点 | 缺点 |
|---|---|
| 最快出原型 | 交互形式有限 |
| 聚焦内容，不折腾 UI | 代码块展示一般 |
| 终端党狂喜 | 非技术用户劝退 |

**推荐库**：
- `rich` — 美化输出（面板、进度条、树、Markdown 渲染）
- `textual` — 完整 TUI 框架（类似 VSCode 终端版）
- `prompt_toolkit` — 高级输入（自动补全、历史记录）

#### B. Web UI（FastAPI + 简单前端）

| 优点 | 缺点 |
|---|---|
| 交互丰富，可拖拽进度树 | 开发量大 3-5 倍 |
| 代码高亮好 | 需要后端 + 前端两套 |
| 可分享链接 | 部署复杂 |

#### C. Hybrid（先 CLI，后加 Web）

```
v0.1 → CLI（rich）
v0.5 → 加一个 Web 版（FastAPI + Streamlit）
v1.0 → 精修其中一个
```

**推荐：Hybrid 路线。** v0.1 用 rich 做 CLI，最快验证核心逻辑。后期如果 CLI 不够用，FastAPI + 简单 HTML 模板就能起 Web 版。

---

### 2.4 数据存储

#### A. JSON 文件

| 优点 | 缺点 |
|---|---|
| 零依赖，人可以直接打开看 | 无查询能力，需要全量加载 |
| AI 可以直接生成/修改 | 并发写入需要自己处理 |
| 结构自由 | 没有 schema 校验 |

#### B. SQLite

| 优点 | 缺点 |
|---|---|
| SQL 查询，可以用 WHERE 找数据 | AI 不擅长直接写 SQL |
| 并发安全 | 数据不直观（需要工具查看） |
| 一个文件，单二进制依赖 | schema 变更需要 migration |

#### C. Markdown + YAML Frontmatter（Obsidian 风格）

```
---
id: m1_c2
title: 条件语句
status: in_progress
mastery: 0.45
---

# 条件语句

学习笔记内容直接写在这里...
```

| 优点 | 缺点 |
|---|---|
| 人可以直接读、直接编辑 | 解析 frontmatter 比纯 JSON 麻烦 |
| 笔记 = 数据，不需要两份文件 | 不适合嵌套深的结构（课程树） |
| 可以用 Obsidian 打开浏览 | |

**推荐：JSON 文件**。对于课程树、知识状态这类结构化数据，JSON 最直接。笔记用 Markdown 存。两者各司其职。

---

### 2.5 AI SDK

| | OpenAI SDK | Anthropic SDK | LiteLLM |
|---|---|---|---|
| 支持模型 | OpenAI 全系 | Claude 全系 | 统一接口，支持 100+ 模型 |
| 切换成本 | 换 SDK | 换 SDK | 改一个字符串 |
| 复杂度 | 低 | 低 | 中 |
| 推荐 | 如果你用 OpenAI | 如果你用 Claude | 如果你想不锁定厂商 |

**推荐：LiteLLM**。一行代码切换模型。学习工具不应该绑定 AI 厂商。

---

### 2.6 推荐技术栈组合

#### 方案一：Python 全栈（强烈推荐给你）

```
语言：     Python 3.12+
CLI：      rich + prompt_toolkit
Web（后期）：FastAPI + Jinja2 + HTMX（不需要写 JS）
AI SDK：   litellm
数据：     JSON + Markdown 文件
包管理：   uv
```

- 你正在学 Python → 项目即学习
- AI 对 Python 代码辅助最好
- FastAPI + HTMX 让你做 Web UI 不用学前端框架

#### 方案二：TypeScript 全栈（如果你未来想做 Web 开发）

```
语言：     TypeScript
CLI：      ink (React 组件写 CLI)
Web：      Next.js / Vite + React
AI SDK：   Vercel AI SDK
数据：     JSON + Markdown 文件
包管理：   pnpm
```

- 前后端同一种语言
- Web UI 能力最强
- 但你得先学会 TypeScript

#### 方案三：Go TUI（如果你想做精美的终端应用）

```
语言：     Go
CLI/TUI：  bubbletea + lipgloss + glamour
AI SDK：   手写 HTTP + JSON 解析
数据：     JSON + Markdown 文件
分发：     单文件二进制
```

- TUI 效果最好（lazygit、gh-dash 那种级别）
- 编译成单文件，发给别人直接用
- 但 AI 辅助写 Go 不如 Python 好

---

## 三、多主题支持的架构调整

当前模型已经支持，但需要明确一条：

### 主题配置文件 `subjects.json`

```jsonc
// data/subjects.json  — 放在 data 目录顶层，管理系统中的所有学习主题
{
  "active_subject": "python",
  "subjects": [
    {
      "id": "python",
      "name": "Python 全流程",
      "status": "in_progress",
      "created_at": "2026-07-17",
      "progress": {
        "total_chapters": 20,
        "completed": 3,
        "in_progress": 1,
        "current_node": "m1_c2"
      }
    },
    {
      "id": "javascript",
      "name": "JavaScript 基础",
      "status": "not_started",
      "created_at": "2026-07-20",
      "progress": null
    }
  ]
}
```

切换主题时：

```
$ estudio switch javascript

已切换到「JavaScript 基础」
  - 大纲已存在：35 个章节
  - 进度：第 0 章（未开始）
  - 最后活动：从未

要开始学习吗？[Y/n]
```

### 跨主题知识关联（未来功能）

不同主题之间可能有共享概念：

```yaml
concept: "递归"
appears_in:
  - subject: python
    chapter: m4_c3
  - subject: javascript
    chapter: m4_c2
  - subject: algorithms
    chapter: m1_c5
```

这意味着如果你在 Python 中已经掌握了"递归"，学 JavaScript 时系统会提示"这个概念你已经会了，快速过一遍就行"。但这是 v2.0 的事，不着急。

---

## 四、最终推荐

| 选型 | 答案 |
|---|---|
| 语言 | **Python**（一举两得：学习工具 + 学习过程） |
| CLI | **rich**（美化输出）+ **prompt_toolkit**（输入） |
| 数据 | **JSON**（结构化状态）+ **Markdown**（笔记） |
| AI | **litellm**（不锁定厂商） |
| 包管理 | **uv** |
| 多主题 | **v0.1 就支持**（只是一个 subjects.json + 目录结构） |
| UI 演进 | v0.1 CLI → v0.5 加 Web → v1.0 精修 |
